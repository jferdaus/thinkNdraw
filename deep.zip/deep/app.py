
from __future__ import print_function
from flask import Flask, render_template, make_response
from flask import redirect, request, jsonify, url_for
from keras import backend as K
from keras import layers
from keras.models import load_model, Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers.convolutional import Conv2D, MaxPooling2D

import os
import numpy as np
import cv2
from PIL import Image
import base64
from io import BytesIO

import logging as log                                                                 
#import sys

app = Flask(__name__)
#app.secret_key = 's3cr3t'
app.debug = True

#app._static_folder = os.path.abspath("templates/static/")

@app.route('/homepage/')
def homepage():
    return render_template('index.html')

@app.route('/', methods=['GET'])
def index():
    # Main page
    return render_template('index.html')

@app.route('/nextpage/')
def nextpage():
    return render_template('first.html')



@app.route('/postmethod', methods = ['POST'])
def post_javascript_data():
    
    
    img = cv2.imread(request.form['canvas_data'], cv2.IMREAD_GRAYSCALE)  
    
    data_url = request.form['canvas_data']
    # Decoding base64 string to bytes object
    offset = data_url.index(',')+1
    img_bytes = base64.b64decode(data_url[offset:])
    img = Image.open(BytesIO(img_bytes))
    img  = np.array(img)
    cv2.imwrite('requestImage/trial.png',img)
    
    im = cv2.imread("requestImage/trial.png", cv2.IMREAD_GRAYSCALE)
    im_resized = cv2.resize(im, (28, 28))
    im_resized = im_resized/255.0
    
    
    
    im = im_resized.reshape(28, 28, 1)
    im = im.reshape(1, 28, 28, 1)
    
    #app.logger.info(im)
    #app.logger.info("classifier loadin...")
    
    model = load_model('TnDmodelV8.h5')
    #app.logger.info(model.summary())
   
    pr = model.predict(im)
    
    app.logger.info(pr)
    #del model
    
    K.clear_session()

    
    
   
    
   

    """index = 0
    mx = 0
    for i in range(0,5):
        if pr.item(i) > mx:
            mx = pr.item(i)
            index = i
            
    s = 'Class: '+str(index)+'\nProbability: '+ str(mx)  """
    
    

     
     
    if (np.argmax(pr)==2):
        s = "success"
    else:
        s = "failure"
      
 
   # s = 'Class: ' + str(result[0]) + '\nProbability: '+ str(res)  

    
    #app.logger.info(s)
    
    
    app.logger.info(np.argmax(pr))
    app.logger.info(np.amax(pr))
    
    
    #app.logger.info(result[0])
    
    
    
    #params = { 'pro' : res }
    
    
    return jsonify(s)
   


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

