$( document ).ready(function() {
  //timer();
  function createCanvas(parent, width, height) {
    var canvas = document.getElementById("inputCanvas");
    canvas.context = canvas.getContext('2d');
    return canvas;
  }

  function init(container, width, height, fillColor) {

    var canvas = createCanvas(container, width, height);
    var ctx = canvas.context;
    ctx.fillCircle = function(x, y, radius, fillColor) {
      this.fillStyle = fillColor;
      this.beginPath();
      this.moveTo(x, y);
      this.arc(x, y, radius, 0, Math.PI * 2.2, false);
      this.fill();
    };
    ctx.clearTo = function(fillColor) {
      ctx.fillStyle = fillColor;
      ctx.fillRect(0, 0, width, height);
    };
    ctx.clearTo("#fff");

    canvas.onmousemove = function(e) {
     
      if (!canvas.isDrawing) {
        return;
      }
      var x = e.pageX - this.offsetLeft;
      var y = e.pageY - this.offsetTop;
      var radius = 10;
      var fillColor = 'rgb(0,0,0)';
      ctx.fillCircle(x, y, radius, fillColor);
      
    };
    canvas.onmousedown = function(e) {
      canvas.isDrawing = true;
    };
    canvas.onmouseup = function(e) {
      canvas.isDrawing = false;

      /*setTimeout(function(){
        var submit_button = document.getElementById("sendButton");
        submit_button.click();
      }, 2);

*/

    };
    canvas.mouseleave = function(e) {
      canvas.isDrawing = false;
    };
  }

  var container = document.getElementById('canvas');
  init(container, 400, 400, '#34eb95');

  function clearCanvas() {
    var canvas = document.getElementById("inputCanvas");
    var ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        canvas.isDrawing = false;
  }

  function getData() {
    var canvas = document.getElementById("inputCanvas");
    var imageData = canvas.context.getImageData(0, 0, canvas.width, canvas.height);
    $.post( "/postmethod", {
      canvas_data: JSON.stringify(canvas.toDataURL())
    }, function(err, req, resp){

      //console.log( resp );
      //alert(err);
        if (err == "success")
        {

        $.alert({
        title: '<p style="color:green;">Congratulations!</p>',
        content: '<p>Yes, You found apple and I found the gravity!</p><img src="../static/image/img_newton_success.gif" alt="No Image" id="img0">',
        //content: err,
        });

        }


        else 
        {

        $.alert({
        title: '<p style="color:red;">Wrong Answer!</p>',
        content: '<p>Apple: Please draw the answer more accurately. Draw again. </p><img src="../static/image/img_newton_failure.gif" alt="No Image" id="img0">',
        //content: err,
        });




        }
        
      

      // window.location.href = "/results/"+resp["responseJSON"]["uuid"];  
    });
  }

  /*function timer() {
    var seconds = document.getElementById("countdown").textContent;
    var countdown = setInterval(function(){
      seconds--;
      (seconds == 1) ? document.getElementById("plural").textContent = "" : document.getElementById("plural").textContent = "s";
      document.getElementById("countdown").textContent = seconds;


      if (seconds <= 0) {clearInterval(countdown); clearCanvas();}
    },1000);


  }
  */

  $( "#clearButton" ).click(function(){
    clearCanvas();
  });

  $( "#sendButton" ).click(function(){
    getData();
  });

  $( "#startButton" ).click(function(){
    if (document.getElementById("countdown").textContent == 0) {
      document.getElementById("countdown").textContent = 10;
     // timer();
    }
  });
});